---
name: cpu-flamegraph-examples
author: mikegguo@tencent.com
---

# cpu-flamegraph 示例 Prompt

以下是触发 cpu-flamegraph skill 的典型用户 prompt 示例，覆盖各类使用场景。

## CPU 热点分析

```
帮我对进程 PID 1234 做 CPU 热点分析，生成火焰图
```

```
系统 CPU 使用率持续偏高，帮我用火焰图定位热点函数
```

```
采样 CPU 0-3 上的内核态热点，生成火焰图
```

```
用 perf-prof profile 对当前系统做 30 秒 CPU 采样，输出火焰图 SVG
```

## 进程/线程级分析

```
我的 Java 进程 CPU 占用高，帮我生成用户态火焰图看看热点在哪
```

```
帮我分析 nginx worker 进程的 CPU 消耗，生成火焰图
```

```
对 PID 5678 和 PID 5679 两个线程采样，合并生成火焰图
```

## 内核事件调用栈分析

```
帮我用 trace 分析 sched:sched_switch 事件的调用栈，生成火焰图
```

```
想看内存分配 kmalloc 的调用路径分布，用火焰图展示
```

```
帮我分析缺页异常的调用栈热点
```

## 进程阻塞分析

```
进程经常处于 D 状态，帮我用 task-state 火焰图定位阻塞在哪
```

```
用 task-state 分析系统中不可中断睡眠（D状态）的调用路径
```

## 火焰图文件操作

```
我已经有一个 cpu.folded 折叠栈文件，帮我用 flamegraph.pl 转成 SVG
```

```
帮我分析这个火焰图文件 /tmp/profile.folded，找出占比最高的函数路径
```

```
火焰图里 __do_softirq 占比很高，帮我解读一下
```

## 综合场景

```
系统整体性能下降，帮我做一次全面的 CPU 热点火焰图分析
```

```
帮我对比采样优化前后的火焰图，看看热点是否有改善
```

```
生成一个火焰图，重点关注内核态 CPU 消耗，过滤掉用户态
```
